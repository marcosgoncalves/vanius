
<?php 
$cats = 
array (
  'cat-appetizers' => 
  array (
    'name' => 'Appetizers',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-beef' => 
  array (
    'name' => 'Beef',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-beverages' => 
  array (
    'name' => 'Beverages',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-chicken' => 
  array (
    'name' => 'Chicken',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-desserts' => 
  array (
    'name' => 'Desserts',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-egg' => 
  array (
    'name' => 'Egg',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-salads' => 
  array (
    'name' => 'Salads',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-seafood' => 
  array (
    'name' => 'Seafood',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-uncategorized' => 
  array (
    'name' => 'Uncategorized',
    'description' => '',
    'taxonomy' => 'category',
  ),
);
