<?php 
$menus = 
array (
  'primary' => 
  array (
    'name' => 'Primary Menu',
    'is_mega' => 0,
    'mega_item' => '',
    'columns_item' => '',
    'children' => 
    array (
      'i-773' => 
      array (
        'order' => '22',
        'title' => 'Features',
        'type' => 'custom',
        'url' => '#',
        'children' => 
        array (
          'i-1446' => 
          array (
            'order' => '51',
            'title' => 'Video',
            'type' => 'custom',
            'url' => '#',
            'children' => 
            array (
              'i-1530' => 
              array (
                'order' => '59',
                'title' => 'Vimeo Video',
                'type' => 'post',
                'url' => '#',
                'post' => '20syl-kodama-official-music-video',
              ),
              'i-1531' => 
              array (
                'order' => '58',
                'title' => 'Youtube Video',
                'type' => 'post',
                'url' => '#',
                'post' => 'rupaul-the-realness-official-music-video',
              ),
              'i-1553' => 
              array (
                'order' => '60',
                'title' => 'Daily Motion Video',
                'type' => 'post',
                'url' => '#',
                'post' => 'hd-jessie-j-ariana-grande-nicki-minaj-bang-bang-amas-2014',
              ),
              'i-1587' => 
              array (
                'order' => '61',
                'title' => 'Facebook Video',
                'type' => 'post',
                'url' => '#',
                'post' => 'facebook-video',
              ),
              'i-1932' => 
              array (
                'order' => '64',
                'type' => 'page',
                'url' => '#',
                'page' => 'all-videos',
              ),
              'i-2218' => 
              array (
                'order' => '52',
                'title' => 'FullWidth Style 1',
                'type' => 'post',
                'url' => '#',
                'post' => 'youtubes-new-music-app',
              ),
              'i-2219' => 
              array (
                'order' => '53',
                'title' => 'FullWidth Style 2',
                'type' => 'post',
                'url' => '#',
                'post' => 'dope-tech-2-customs',
              ),
              'i-2222' => 
              array (
                'order' => '56',
                'title' => 'Inbox Style 1',
                'type' => 'post',
                'url' => '#',
                'post' => 'worlds-greatest-drag-race-4',
              ),
              'i-2223' => 
              array (
                'order' => '57',
                'title' => 'Inbox Style 2',
                'type' => 'post',
                'url' => '#',
                'post' => 'best-of-red-bull-2012-2014-best-of-extreme-sport-compilation-music-video',
              ),
              'i-2311' => 
              array (
                'order' => '54',
                'title' => 'Wide Style 1',
                'type' => 'post',
                'url' => '#',
                'post' => 'nev-plays-best-of-mrsuicidesheep',
              ),
              'i-2312' => 
              array (
                'order' => '55',
                'title' => 'Wide Style 2',
                'type' => 'post',
                'url' => '#',
                'post' => 'a-traks-short-cuts-money-makin-routine',
              ),
              'i-2314' => 
              array (
                'order' => '63',
                'title' => 'Live Video',
                'type' => 'post',
                'url' => '#',
                'post' => 'top-10-tank-champions-league-of-legends',
              ),
              'i-3018' => 
              array (
                'order' => '62',
                'type' => 'post',
                'url' => '#',
                'post' => 'self-hosted-video',
              ),
            ),
          ),
          'i-1466' => 
          array (
            'order' => '88',
            'title' => 'Categories',
            'type' => 'custom',
            'url' => '#',
            'children' => 
            array (
              'i-1692' => 
              array (
                'order' => '91',
                'title' => 'Layout 3',
                'type' => 'category',
                'url' => '#',
                'category' => 'cat-music',
              ),
              'i-1693' => 
              array (
                'order' => '92',
                'title' => 'Width Avatar',
                'type' => 'category',
                'url' => '#',
                'category' => 'cat-sport',
              ),
              'i-1694' => 
              array (
                'order' => '90',
                'title' => 'Layout 2',
                'type' => 'category',
                'url' => '#',
                'category' => 'cat-movie',
              ),
              'i-1695' => 
              array (
                'order' => '89',
                'title' => 'Layout 1',
                'type' => 'category',
                'url' => '#',
                'category' => 'cat-game',
              ),
              'i-1696' => 
              array (
                'order' => '93',
                'title' => 'No Avatar',
                'type' => 'category',
                'url' => '#',
                'category' => 'cat-kombat',
              ),
            ),
          ),
          'i-1697' => 
          array (
            'order' => '94',
            'title' => 'Video Series',
            'type' => 'custom',
            'url' => '#',
            'children' => 
            array (
              'i-1702' => 
              array (
                'order' => '95',
                'type' => 'page',
                'url' => '#',
                'page' => 'series-list',
              ),
              'i-2317' => 
              array (
                'order' => '97',
                'title' => 'Series Video V1',
                'type' => 'custom',
                'url' => 'http://videopro.cactusthemes.com/v2/cgi-animated-short-film-hd-quantum-jump-short-film-by-hayk-sahakyants/?series=movie',
              ),
              'i-2318' => 
              array (
                'order' => '98',
                'title' => 'Series Video V2',
                'type' => 'custom',
                'url' => 'http://videopro.cactusthemes.com/v2/run-inspirational-running-video-hd/?series=sport',
              ),
              'i-2830' => 
              array (
                'order' => '96',
                'title' => 'Single Series',
                'type' => 'video-series',
                'url' => '#',
              ),
            ),
          ),
          'i-2214' => 
          array (
            'order' => '65',
            'title' => 'Articles',
            'type' => 'custom',
            'url' => '#',
            'children' => 
            array (
              'i-2215' => 
              array (
                'order' => '66',
                'title' => 'Standard Layout',
                'type' => 'custom',
                'url' => '#',
                'children' => 
                array (
                  'i-2224' => 
                  array (
                    'order' => '67',
                    'title' => 'FullWidth Style 1',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'these-cheap-will-upgrade-your-space',
                  ),
                  'i-2225' => 
                  array (
                    'order' => '68',
                    'title' => 'FullWidth Style 2',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'new-zenland-eco-fashion-week-opens-in-style',
                  ),
                  'i-2226' => 
                  array (
                    'order' => '69',
                    'title' => 'Wide Style 1',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'successful-businessman-in-the-new-era',
                  ),
                  'i-2227' => 
                  array (
                    'order' => '70',
                    'title' => 'Wide Style 2',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'day-in-the-life-of-an-internet-commenter',
                  ),
                  'i-2228' => 
                  array (
                    'order' => '71',
                    'title' => 'Inbox Style 1',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'fewer-auctions-but-still-strongs-home-sale-amount',
                  ),
                  'i-2229' => 
                  array (
                    'order' => '72',
                    'title' => 'Inbox Style 2',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'fitness-does-wearable-fitness-gear-work',
                  ),
                  'i-2990' => 
                  array (
                    'order' => '73',
                    'title' => 'Video With Thumbnail Image Header',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'youtubes-new-music-app',
                  ),
                ),
              ),
              'i-2216' => 
              array (
                'order' => '74',
                'title' => 'Gallery Layout',
                'type' => 'custom',
                'url' => '#',
                'children' => 
                array (
                  'i-2230' => 
                  array (
                    'order' => '75',
                    'title' => 'FullWidth Style 1',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'mobile-kiosk-available-at-fitness-center-from-today',
                  ),
                  'i-2231' => 
                  array (
                    'order' => '76',
                    'title' => 'FullWidth Style 2',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'it-is-beyound-blogging',
                  ),
                  'i-2232' => 
                  array (
                    'order' => '77',
                    'title' => 'Wide Style 1',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'all-my-life-by-gentlemans-rule',
                  ),
                  'i-2233' => 
                  array (
                    'order' => '78',
                    'title' => 'Wide Style 2',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'will-genetic-cyber-athletes-dominate-sports',
                  ),
                  'i-2234' => 
                  array (
                    'order' => '79',
                    'title' => 'Inbox Style 1',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'bizzline-a-studio-for-photographers-set-to-open',
                  ),
                  'i-2235' => 
                  array (
                    'order' => '80',
                    'title' => 'Inbox Style 2',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'mobile-content-ecosystem-odm-must-evolve-or-disssove',
                  ),
                ),
              ),
              'i-2217' => 
              array (
                'order' => '81',
                'title' => 'Audio Layout',
                'type' => 'custom',
                'url' => '#',
                'children' => 
                array (
                  'i-2236' => 
                  array (
                    'order' => '82',
                    'title' => 'FullWidth Style 1',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'happy-cover-by-kings-road',
                  ),
                  'i-2237' => 
                  array (
                    'order' => '83',
                    'title' => 'FullWidth Style 2',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'swith-between-front-and-rear-camerasfor-videos',
                  ),
                  'i-2238' => 
                  array (
                    'order' => '84',
                    'title' => 'Wide Style 1',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'some-nights-veritones-a-cappella-cover',
                  ),
                  'i-2239' => 
                  array (
                    'order' => '85',
                    'title' => 'Wide Style 2',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'all-my-life-by-gentlemans-rule-2',
                  ),
                  'i-2240' => 
                  array (
                    'order' => '86',
                    'title' => 'Inbox Style 1',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'crazy-a-capella-by-veritones',
                  ),
                  'i-2241' => 
                  array (
                    'order' => '87',
                    'title' => 'Inbox Style 2',
                    'type' => 'post',
                    'url' => '#',
                    'post' => 'i-choose-love-performed-by-kings-road',
                  ),
                ),
              ),
            ),
          ),
          'i-2472' => 
          array (
            'order' => '99',
            'title' => 'Channel',
            'type' => 'custom',
            'url' => '#',
            'children' => 
            array (
              'i-2477' => 
              array (
                'order' => '100',
                'title' => 'Demo Channel',
                'type' => 'ct_channel',
                'url' => '#',
              ),
            ),
          ),
          'i-2473' => 
          array (
            'order' => '101',
            'title' => 'Playlist',
            'type' => 'custom',
            'url' => '#',
            'children' => 
            array (
              'i-2478' => 
              array (
                'order' => '102',
                'title' => 'Playlist',
                'type' => 'ct_playlist',
                'url' => '#',
              ),
              'i-2479' => 
              array (
                'order' => '103',
                'title' => 'Playlist View',
                'type' => 'custom',
                'url' => 'http://videopro.cactusthemes.com/v2/cgi-animated-short-film-hd-quantum-jump-short-film-by-hayk-sahakyants/?list=794',
              ),
            ),
          ),
          'i-2476' => 
          array (
            'order' => '23',
            'title' => 'Shortcodes',
            'type' => 'custom',
            'url' => '#',
            'children' => 
            array (
              'i-2491' => 
              array (
                'order' => '24',
                'title' => 'Block',
                'type' => 'custom',
                'url' => '#',
                'children' => 
                array (
                  'i-2492' => 
                  array (
                    'order' => '39',
                    'title' => 'Block 15',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v15',
                  ),
                  'i-2493' => 
                  array (
                    'order' => '38',
                    'title' => 'Block 14',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v14',
                  ),
                  'i-2494' => 
                  array (
                    'order' => '37',
                    'title' => 'Block 13',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v13',
                  ),
                  'i-2495' => 
                  array (
                    'order' => '36',
                    'title' => 'Block 12',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v12',
                  ),
                  'i-2496' => 
                  array (
                    'order' => '35',
                    'title' => 'Block 11',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v11',
                  ),
                  'i-2497' => 
                  array (
                    'order' => '34',
                    'title' => 'Block 10',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v10',
                  ),
                  'i-2498' => 
                  array (
                    'order' => '33',
                    'title' => 'Block 9',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v9',
                  ),
                  'i-2499' => 
                  array (
                    'order' => '32',
                    'title' => 'Block 8',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v8',
                  ),
                  'i-2500' => 
                  array (
                    'order' => '31',
                    'title' => 'Block 7',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v7',
                  ),
                  'i-2505' => 
                  array (
                    'order' => '25',
                    'title' => 'Block 1',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v1',
                  ),
                  'i-2506' => 
                  array (
                    'order' => '26',
                    'title' => 'Block 2',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v2',
                  ),
                  'i-2507' => 
                  array (
                    'order' => '27',
                    'title' => 'Block 3',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v3',
                  ),
                  'i-2508' => 
                  array (
                    'order' => '28',
                    'title' => 'Block 4',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v4',
                  ),
                  'i-2509' => 
                  array (
                    'order' => '29',
                    'title' => 'Block 5',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v5',
                  ),
                  'i-2510' => 
                  array (
                    'order' => '30',
                    'title' => 'Block 6',
                    'type' => 'page',
                    'url' => '#',
                    'page' => 'smart-content-box-v6',
                  ),
                ),
              ),
              'i-2514' => 
              array (
                'order' => '40',
                'type' => 'page',
                'url' => '#',
                'page' => 'actors-list',
              ),
              'i-2515' => 
              array (
                'order' => '41',
                'title' => 'Channel List',
                'type' => 'page',
                'url' => '#',
                'page' => 'channel-list-shortcode',
              ),
              'i-2516' => 
              array (
                'order' => '42',
                'title' => 'Series List',
                'type' => 'page',
                'url' => '#',
                'page' => 'series-listing-shortcode',
              ),
              'i-2517' => 
              array (
                'order' => '43',
                'type' => 'page',
                'url' => '#',
                'page' => 'elements',
              ),
              'i-2518' => 
              array (
                'order' => '47',
                'type' => 'page',
                'url' => '#',
                'page' => 'newsletter',
              ),
              'i-2519' => 
              array (
                'order' => '48',
                'type' => 'page',
                'url' => '#',
                'page' => 'promo-box',
              ),
              'i-2521' => 
              array (
                'order' => '44',
                'type' => 'page',
                'url' => '#',
                'page' => 'typography',
              ),
              'i-2522' => 
              array (
                'order' => '46',
                'type' => 'page',
                'url' => '#',
                'page' => 'contact-form',
              ),
              'i-2523' => 
              array (
                'order' => '49',
                'title' => 'Photo Caption',
                'type' => 'post',
                'url' => '#',
                'post' => 'the-one-thing-that-make-a-match-work',
              ),
              'i-2524' => 
              array (
                'order' => '50',
                'title' => 'Protected Content',
                'type' => 'post',
                'url' => '#',
                'post' => 'sidekick-animated-short-film-for-children',
              ),
              'i-2657' => 
              array (
                'order' => '45',
                'title' => 'Pricing Table',
                'type' => 'page',
                'url' => '#',
                'page' => 'shortcode-compare-table',
              ),
            ),
          ),
          'i-2480' => 
          array (
            'order' => '104',
            'title' => 'Video Rating',
            'type' => 'custom',
            'url' => '#',
            'children' => 
            array (
              'i-2481' => 
              array (
                'order' => '105',
                'title' => 'Rating Point',
                'type' => 'post',
                'url' => '#',
                'post' => '2015-beginner-ish-sportbike-shootout',
              ),
              'i-2482' => 
              array (
                'order' => '106',
                'title' => 'Rating Star',
                'type' => 'post',
                'url' => '#',
                'post' => 'o6-free-your-eyes',
              ),
            ),
          ),
          'i-2483' => 
          array (
            'order' => '110',
            'title' => 'Multi-link Videos',
            'type' => 'post',
            'url' => '#',
            'post' => 'facebook-video',
          ),
          'i-2484' => 
          array (
            'order' => '107',
            'title' => 'Actor',
            'type' => 'custom',
            'url' => '#',
            'children' => 
            array (
              'i-2490' => 
              array (
                'order' => '108',
                'title' => 'Demo Actor',
                'type' => 'ct_actor',
                'url' => '#',
              ),
            ),
          ),
          'i-2486' => 
          array (
            'order' => '112',
            'title' => 'Author Page',
            'type' => 'custom',
            'url' => 'http://videopro.cactusthemes.com/v2/uploader/hoaintt/',
          ),
          'i-2487' => 
          array (
            'order' => '113',
            'title' => 'Social Locker',
            'type' => 'post',
            'url' => '#',
            'post' => 'sidekick-animated-short-film-for-children',
          ),
          'i-2488' => 
          array (
            'order' => '116',
            'title' => 'Search',
            'type' => 'custom',
            'url' => 'http://videopro.cactusthemes.com/v2/?s=music',
          ),
          'i-2489' => 
          array (
            'order' => '117',
            'title' => 'Page Not Found',
            'type' => 'custom',
            'url' => 'http://videopro.cactusthemes.com/v2/404',
          ),
          'i-2579' => 
          array (
            'order' => '111',
            'type' => 'page',
            'url' => '#',
            'page' => 'video-badges',
          ),
          'i-2734' => 
          array (
            'order' => '115',
            'type' => 'page',
            'url' => '#',
            'page' => 'maintenance',
          ),
          'i-2735' => 
          array (
            'order' => '114',
            'type' => 'page',
            'url' => '#',
            'page' => 'coming-soon',
          ),
          'i-2834' => 
          array (
            'order' => '109',
            'title' => 'Video Ads',
            'type' => 'post',
            'url' => '#',
            'post' => 'spooly-worlds-first-magnetic-charging-cables',
          ),
        ),
      ),
      'i-1589' => 
      array (
        'order' => '1',
        'title' => 'Home',
        'type' => 'custom',
        'url' => '#',
        'children' => 
        array (
          'i-1590' => 
          array (
            'order' => '7',
            'type' => 'page',
            'url' => '#',
            'page' => 'home-page-v6',
          ),
          'i-1591' => 
          array (
            'order' => '6',
            'type' => 'page',
            'url' => '#',
            'page' => 'home-page-v5',
          ),
          'i-1592' => 
          array (
            'order' => '5',
            'type' => 'page',
            'url' => '#',
            'page' => 'home-page-v4',
          ),
          'i-1593' => 
          array (
            'order' => '4',
            'type' => 'page',
            'url' => '#',
            'page' => 'home-page-v3',
          ),
          'i-1594' => 
          array (
            'order' => '3',
            'type' => 'page',
            'url' => '#',
            'page' => 'home-page-v2',
          ),
          'i-1595' => 
          array (
            'order' => '12',
            'title' => 'Home Page V11',
            'type' => 'page',
            'url' => '#',
            'page' => 'homepage-game-version',
          ),
          'i-1596' => 
          array (
            'order' => '2',
            'type' => 'page',
            'url' => '#',
            'page' => 'home-page-v1',
          ),
          'i-1867' => 
          array (
            'order' => '11',
            'type' => 'page',
            'url' => '#',
            'page' => 'home-page-v10',
          ),
          'i-1868' => 
          array (
            'order' => '10',
            'type' => 'page',
            'url' => '#',
            'page' => 'home-page-v9',
          ),
          'i-1869' => 
          array (
            'order' => '9',
            'type' => 'page',
            'url' => '#',
            'page' => 'home-page-v8',
          ),
          'i-1870' => 
          array (
            'order' => '8',
            'type' => 'page',
            'url' => '#',
            'page' => 'home-page-v7',
          ),
        ),
      ),
      'i-3189' => 
      array (
        'order' => '134',
        'title' => 'Register',
        'type' => 'page',
        'url' => '#',
        'page' => 'register-3',
      ),
      'i-3236' => 
      array (
        'order' => '118',
        'title' => 'Community',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-3279' => 
      array (
        'order' => '122',
        'title' => 'Browse',
        'type' => 'custom',
        'url' => '#',
        'children' => 
        array (
          'i-3280' => 
          array (
            'order' => '125',
            'type' => 'page',
            'url' => '#',
            'page' => 'all-playlists',
          ),
          'i-3281' => 
          array (
            'order' => '126',
            'title' => 'All Actors',
            'type' => 'page',
            'url' => '#',
            'page' => 'all-actor',
          ),
          'i-3282' => 
          array (
            'order' => '128',
            'type' => 'page',
            'url' => '#',
            'page' => 'all-tags',
          ),
          'i-3283' => 
          array (
            'order' => '127',
            'type' => 'page',
            'url' => '#',
            'page' => 'all-categories',
          ),
          'i-3459' => 
          array (
            'order' => '129',
            'title' => 'User Uploaded Videos',
            'type' => 'category',
            'url' => '#',
            'category' => 'cat-community',
          ),
          'i-3479' => 
          array (
            'order' => '123',
            'type' => 'page',
            'url' => '#',
            'page' => 'all-members',
          ),
        ),
      ),
      'i-3456' => 
      array (
        'order' => '130',
        'title' => 'Premium Content',
        'type' => 'custom',
        'url' => '#',
        'children' => 
        array (
          'i-3457' => 
          array (
            'order' => '131',
            'title' => '[Premium] Protected Post',
            'type' => 'post',
            'url' => '#',
            'post' => 'cut-the-rope-magic-mushroom-land-walkthrough-all-levels',
          ),
          'i-3458' => 
          array (
            'order' => '132',
            'title' => '[Premium] Protected Category',
            'type' => 'category',
            'url' => '#',
            'category' => 'cat-tv-show',
          ),
          'i-3465' => 
          array (
            'order' => '133',
            'title' => '[Premium] Protected Channel',
            'type' => 'ct_channel',
            'url' => '#',
          ),
        ),
      ),
    ),
  ),
  'custom-menu' => 
  array (
    'name' => 'Custom Menu',
    'is_mega' => 0,
    'mega_item' => '',
    'columns_item' => '',
    'children' => 
    array (
      'i-2344' => 
      array (
        'order' => '1',
        'title' => 'About VideoPro',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-2345' => 
      array (
        'order' => '2',
        'title' => 'WordPress Theme',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-2347' => 
      array (
        'order' => '5',
        'title' => 'Contact Us',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-2386' => 
      array (
        'order' => '3',
        'title' => 'Submit Your Video',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-2599' => 
      array (
        'order' => '4',
        'title' => 'For Advertisers',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-3466' => 
      array (
        'order' => '6',
        'type' => 'page',
        'url' => '#',
        'page' => 'page-terms',
      ),
    ),
  ),
  'footer-menu' => 
  array (
    'name' => 'Footer Menu',
    'is_mega' => 0,
    'mega_item' => '',
    'columns_item' => '',
    'children' => 
    array (
      'i-782' => 
      array (
        'order' => '1',
        'title' => 'Home',
        'type' => 'custom',
        'url' => 'http://test.cactusthemes.com/videopro-v1',
      ),
      'i-783' => 
      array (
        'order' => '2',
        'title' => 'About',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-784' => 
      array (
        'order' => '3',
        'title' => 'Contact Us',
        'type' => 'custom',
        'url' => '#',
      ),
    ),
  ),
  'user-menu' => 
  array (
    'name' => 'User Menu',
    'is_mega' => 0,
    'mega_item' => '',
    'columns_item' => '',
    'children' => 
    array (
      'i-2330' => 
      array (
        'order' => '3',
        'type' => 'page',
        'url' => '#',
        'page' => 'subscribed-channels',
      ),
      'i-2982' => 
      array (
        'order' => '1',
        'type' => 'page',
        'url' => '#',
        'page' => 'watch-later',
      ),
      'i-3171' => 
      array (
        'order' => '5',
        'title' => 'Your Account',
        'type' => 'page',
        'url' => '#',
        'page' => 'account-2',
      ),
      'i-3175' => 
      array (
        'order' => '4',
        'type' => 'page',
        'url' => '#',
        'page' => 'memberships',
      ),
      'i-3192' => 
      array (
        'order' => '2',
        'type' => 'page',
        'url' => '#',
        'page' => 'subscribed-authors',
      ),
    ),
  ),
);
