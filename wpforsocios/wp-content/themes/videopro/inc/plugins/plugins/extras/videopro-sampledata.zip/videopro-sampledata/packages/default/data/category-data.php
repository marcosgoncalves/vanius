
<?php 
$cats = 
array (
  'cat-aww' => 
  array (
    'name' => 'AWW',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-fail' => 
  array (
    'name' => 'FAIL',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-gaming' => 
  array (
    'name' => 'GAMING',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-lol' => 
  array (
    'name' => 'LOL',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-movie-tv' => 
  array (
    'name' => 'MOVIE &amp; TV',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-nsfw' => 
  array (
    'name' => 'NSFW',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-others' => 
  array (
    'name' => 'OTHERS',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-wow' => 
  array (
    'name' => 'WOW',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'cat-wtf' => 
  array (
    'name' => 'WTF',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'woo-action' => 
  array (
    'name' => 'action',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-actor' => 
  array (
    'name' => 'actor',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-actress' => 
  array (
    'name' => 'actress',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-black' => 
  array (
    'name' => 'black',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-drama' => 
  array (
    'name' => 'drama',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-harry-potter-and-the-deathly-hallows' => 
  array (
    'name' => 'Harry Potter and the Deathly Hallows',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-i-know-what-you-did-last-night' => 
  array (
    'name' => 'I know what you did last night',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-independent-2016' => 
  array (
    'name' => 'Independent (2016)',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-model' => 
  array (
    'name' => 'model',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-movie' => 
  array (
    'name' => 'movie',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-pirates-of-the-caribbean' => 
  array (
    'name' => 'Pirates of the Caribbean',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-polite' => 
  array (
    'name' => 'polite',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-producer' => 
  array (
    'name' => 'producer',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-sexy' => 
  array (
    'name' => 'sexy',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-silicon-valley' => 
  array (
    'name' => 'Silicon Valley',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-the-last-day' => 
  array (
    'name' => 'The Last Day',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-trailer' => 
  array (
    'name' => 'trailer',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-writer' => 
  array (
    'name' => 'writer',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
);
