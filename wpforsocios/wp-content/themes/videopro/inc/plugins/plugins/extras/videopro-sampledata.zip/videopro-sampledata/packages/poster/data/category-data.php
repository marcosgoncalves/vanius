
<?php 
$cats = 
array (
  'cat-action' => 
  array (
    'name' => 'Action',
    'description' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
    'taxonomy' => 'category',
  ),
  'cat-comedy' => 
  array (
    'name' => 'Comedy',
    'description' => 'Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
    'taxonomy' => 'category',
  ),
  'cat-drama' => 
  array (
    'name' => 'Drama',
    'description' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.',
    'taxonomy' => 'category',
  ),
  'cat-others' => 
  array (
    'name' => 'OTHERS',
    'description' => '',
    'taxonomy' => 'category',
  ),
  'woo-action' => 
  array (
    'name' => 'action',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-actor' => 
  array (
    'name' => 'actor',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-actress' => 
  array (
    'name' => 'actress',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-black' => 
  array (
    'name' => 'black',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-david-fincher-the-game' => 
  array (
    'name' => 'David Fincher The Game',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-drama' => 
  array (
    'name' => 'drama',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-harry-potter-and-the-deathly-hallows' => 
  array (
    'name' => 'Harry Potter and the Deathly Hallows',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-model' => 
  array (
    'name' => 'model',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-movie' => 
  array (
    'name' => 'movie',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-movie-inception' => 
  array (
    'name' => 'Movie Inception',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-movie-poster' => 
  array (
    'name' => 'Movie Poster',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-polite' => 
  array (
    'name' => 'polite',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-producer' => 
  array (
    'name' => 'producer',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-sexy' => 
  array (
    'name' => 'sexy',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-the-silence-of-the-lambs' => 
  array (
    'name' => 'The Silence Of The Lambs',
    'taxonomy' => 'video-series',
    'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
  ),
  'woo-trailer' => 
  array (
    'name' => 'trailer',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
  'woo-writer' => 
  array (
    'name' => 'writer',
    'taxonomy' => 'actor_tag',
    'description' => '',
  ),
);
